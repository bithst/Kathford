# Lab 5

Parse the given string using parsing table generated from previous lab

>Date: 2075/06/18 | 2018-10-04