# Labs

1. Convert the infix expression a+b-c to postfix.
2. Calculate fisrtpos(), lastpos() and followpos() for RE (a+b)*abb
3. Calculation of first and follow for the given grammar
4. Construction of predictive parsing table from Lab 3
5. Parse the given string using parsing table generated in Lab 4
6. Convert the given expression a=b+(-c)+(c*d) into ThreeAddressCode(TAC).
