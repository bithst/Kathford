# CDC Lab

Convert the infix expression `a+b-c` to postfix.
>Date: 2018/08/23 | 2075/05/07