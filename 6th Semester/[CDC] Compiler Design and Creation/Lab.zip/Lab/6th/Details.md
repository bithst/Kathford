# Lab 6

Convert the given expression into three address code

>Date: 2075/08/06 | 2018-11-22