# Lab 2

Calculate the firstpos(), lastpos() & followpos() for the regular expression (a+b)*abb
>Date: 2018-09-04 | 2075/05/19